package com.example.magnetradar;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.RectF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.View;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor magnetometer;
    private RadarView radarView;
    private TextView valueText, statusText, sensorText;
    private float field = 0f;
    private boolean hasReading = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(4, 13, 24));
        getWindow().setNavigationBarColor(Color.rgb(4, 13, 24));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(16));
        root.setBackgroundColor(Color.rgb(4, 13, 24));

        TextView title = new TextView(this);
        title.setText("MAGNET RADAR");
        title.setTextColor(Color.rgb(95, 255, 195));
        title.setTextSize(24);
        title.setLetterSpacing(0.12f);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView subtitle = new TextView(this);
        subtitle.setText("PEMANTAU MEDAN MAGNET");
        subtitle.setTextColor(Color.rgb(135, 164, 184));
        subtitle.setTextSize(11);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(24)));

        radarView = new RadarView(this);
        LinearLayout.LayoutParams radarParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        radarParams.topMargin = dp(10);
        radarParams.bottomMargin = dp(8);
        root.addView(radarView, radarParams);

        valueText = new TextView(this);
        valueText.setText("Menunggu sensor…");
        valueText.setTextColor(Color.WHITE);
        valueText.setTextSize(30);
        valueText.setGravity(Gravity.CENTER);
        valueText.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        root.addView(valueText, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView unitText = new TextView(this);
        unitText.setText("µT  •  TOTAL MEDAN MAGNET");
        unitText.setTextColor(Color.rgb(135, 164, 184));
        unitText.setTextSize(11);
        unitText.setGravity(Gravity.CENTER);
        root.addView(unitText, new LinearLayout.LayoutParams(-1, dp(22)));

        statusText = new TextView(this);
        statusText.setText("Memeriksa sensor perangkat");
        statusText.setTextColor(Color.rgb(95, 255, 195));
        statusText.setTextSize(14);
        statusText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(32));
        sp.topMargin = dp(10);
        root.addView(statusText, sp);

        sensorText = new TextView(this);
        sensorText.setText("Dekatkan HP ke objek secara perlahan");
        sensorText.setTextColor(Color.rgb(135, 164, 184));
        sensorText.setTextSize(12);
        sensorText.setGravity(Gravity.CENTER);
        root.addView(sensorText, new LinearLayout.LayoutParams(-1, dp(28)));

        TextView note = new TextView(this);
        note.setText("Sensor hanya mengukur medan magnet di sekitar HP, bukan memindai semua benda di balik tembok.");
        note.setTextColor(Color.rgb(145, 160, 175));
        note.setTextSize(11);
        note.setGravity(Gravity.CENTER);
        note.setPadding(dp(4), dp(8), dp(4), dp(4));
        root.addView(note, new LinearLayout.LayoutParams(-1, dp(48)));

        setContentView(root);
        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (magnetometer == null) {
            statusText.setText("Sensor magnetik tidak tersedia");
            sensorText.setText("Perangkat ini tidak menyediakan sensor yang dibutuhkan.");
        } else {
            sensorText.setText("Sensor: " + magnetometer.getName());
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (sensorManager != null && magnetometer != null)
            sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI);
    }
    @Override protected void onPause() {
        super.onPause();
        if (sensorManager != null) sensorManager.unregisterListener(this);
    }
    @Override public void onSensorChanged(SensorEvent event) {
        float x = event.values[0], y = event.values[1], z = event.values[2];
        field = (float)Math.sqrt(x*x + y*y + z*z);
        hasReading = true;
        valueText.setText(String.format(Locale.getDefault(), "%.1f µT", field));
        if (field < 60f) statusText.setText("MEDAN RELATIF RENDAH");
        else if (field < 100f) statusText.setText("PERUBAHAN MEDAN TERDETEKSI");
        else statusText.setText("MEDAN KUAT • PERIKSA SUMBER MAGNET");
        radarView.invalidate();
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private class RadarView extends View {
        private final Paint p = new Paint(3);
        private float sweep = 0;
        private long last = System.currentTimeMillis();
        RadarView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth()/2f, cy = getHeight()/2f;
            float r = Math.min(getWidth(), getHeight()) * 0.43f;
            canvas.drawColor(Color.rgb(4,13,24));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1));
            p.setColor(Color.rgb(24,85,83));
            for (int i=1;i<=4;i++) canvas.drawCircle(cx,cy,r*i/4f,p);
            canvas.drawLine(cx-r,cy,cx+r,cy,p);
            canvas.drawLine(cx,cy-r,cx,cy+r,p);
            p.setColor(Color.rgb(39,111,100)); p.setStrokeWidth(dp(1));
            canvas.drawCircle(cx,cy,r*0.5f,p);
            long now = System.currentTimeMillis();
            sweep = (sweep + (now-last)*0.10f) % 360f;
            last = now;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(35, 60, 255, 180));
            canvas.drawArc(new RectF(cx-r,cy-r,cx+r,cy+r), sweep-48, 48, true,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2));
            p.setColor(Color.rgb(95,255,195));
            canvas.drawArc(new RectF(cx-r,cy-r,cx+r,cy+r), sweep-2, 4, false,p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(95,255,195));
            canvas.drawCircle(cx,cy,dp(4),p);
            p.setTextSize(dp(10)); p.setColor(Color.rgb(95,190,170));
            p.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("N",cx,cy-r-dp(9),p);
            canvas.drawText("S",cx,cy+r+dp(17),p);
            canvas.drawText("W",cx-r-dp(12),cy+dp(4),p);
            canvas.drawText("E",cx+r+dp(12),cy+dp(4),p);
            if (hasReading) {
                float strength = Math.min(1f, Math.max(0f,(field-25f)/175f));
                p.setColor(Color.argb((int)(70+strength*140),255,180,65));
                float dotR = dp(4) + strength*dp(8);
                canvas.drawCircle(cx + (float)Math.cos(Math.toRadians(sweep))*r*0.62f,
                                  cy + (float)Math.sin(Math.toRadians(sweep))*r*0.62f,
                                  dotR,p);
            }
            postInvalidateDelayed(50);
        }
    }
}
