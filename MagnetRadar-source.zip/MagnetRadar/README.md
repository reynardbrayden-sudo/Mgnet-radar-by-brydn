# Magnet Radar (Android)

A simple native Android app that displays the magnitude of the phone's magnetic-field sensor in microtesla (µT), with a rotating radar-style screen.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `MagnetRadar` folder as a project.
3. Let Gradle sync and install the Android SDK platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The APK is typically generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
- Requires a physical device with `TYPE_MAGNETIC_FIELD` sensor; the app displays a message if unavailable.
- The radar sweep is a visual animation. It does not provide direction or distance to hidden objects.
- Readings are total magnetic field magnitude from the phone sensor and can be affected by the Earth's magnetic field, phone case magnets, speakers, chargers, metal, and nearby electrical equipment.
- This project is source code, not a prebuilt APK.
